## Windows 11 RDP

**Here this tutorial using some Linux VM machine you can use any one like GCP.** <br><br>
***😎 Its One Hours RDP Complatly Free***

<br>

### Using Medthod


- *Open This : https://www.katacoda.com/openshift/courses/subsystems/container-internals-lab-2-0-part-1*
- *Click on start scenario*
- *type in the command as Given Below*

#### 1. First download this script in Linux Environment

~~~
wget -O RDP.sh https://raw.githubusercontent.com/proavipatil/Windows-11-VPS/main/RDP.sh
~~~

#### 2. Now make executable

~~~
chmod +x RDP.sh
~~~

#### 3. Now Run This Script

~~~
./RDP.sh
~~~

- *It will ask you for a ngrok auth token, u can easily get this by signing up on ngrok.com and going to 'Auth token' and copying the token then paste it (right click and then click paste)*

- *Wait for it to setup the windows 11 machine*

- *After its done it will give you  the ip address of the rdp/vps (for example 1.tcp.eu.ngrok.io:57584)*

- *open remote desktop client on windows type the ip and use the credentials provided*


### WARN
```
THIS IS ONLY FOR EDUCATIONAL PURPOSES

DON'T USE FOR MINING OR ILLEGAL USE

DON'T RECODE THIS SC!
```
---

#### Main Repository : https://github.com/proavipatil/Windows-11-VPS
